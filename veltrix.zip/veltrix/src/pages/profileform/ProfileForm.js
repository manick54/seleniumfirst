import React from 'react'
import { useForm, Form } from './useForm';
import * as employeeService from "./employeeService";
import { TextField, Typography } from '@mui/material';
import { Box } from "@mui/material";
import Button from "../../components/button/Button";
import './profileform.scss'




const initialFValues = {
    id: 0,
    fullName: '',
    email: '',
    mobile: '',
	password:'',
    }

export default function ProfileForm() {

    const validate = (fieldValues = values) => {
        let temp = { ...errors }
        if ('fullName' in fieldValues)
            temp.fullName = fieldValues.fullName ? "" : "This field is required."
        if ('email' in fieldValues)
            temp.email = (/$^|.+@.+..+/).test(fieldValues.email) ? "" : "Email is not valid."
        if ('mobile' in fieldValues)
            temp.mobile = fieldValues.mobile.length > 9 ? "" : "Minimum 10 numbers required."
        if ('password' in fieldValues)
            temp.password = fieldValues.password.length !== 0 ? "" : "This field is required."
        setErrors({
            ...temp
        })

        if (fieldValues === values)
            return Object.values(temp).every(x => x === "")
    }

    const {
        values,
        setValues,
        errors,
        setErrors,
        handleInputChange,
        resetForm
    } = useForm(initialFValues, true, validate);

    const handleSubmit = e => {
        e.preventDefault()
        if (validate()){
            employeeService.insertEmployee(values)
            resetForm()
        }
    }

    return (
        <Form onSubmit={handleSubmit} className="formContainer">
			<Typography className='title'>Login</Typography>
            <Box container>
                <Box  xs={6}>
                    <TextField 
					    className='textBox'
                        name="fullName"
						variant="outlined"
                        label="Full Name"
                        value={values.fullName}
                        onChange={handleInputChange}
                        error={errors.fullName}
                    />
                    <TextField
					className='textBox'
                        label="Email"
                        name="email"
						variant="outlined"
                        value={values.email}
                        onChange={handleInputChange}
                        error={errors.email}
                    />
                    <TextField
					className='textBox'
                        label="Mobile"
                        name="mobile"
						variant="outlined"
                        value={values.mobile}
                        onChange={handleInputChange}
                        error={errors.mobile}
                    />
                    <TextField
					className='textBox'
                        label="Password"
                        name="password"
						variant="outlined"
                        value={values.password}
                        onChange={handleInputChange}
						error={errors.password}

                    />

                </Box>
                <Box className='buttonContainer' >
				<Button
                            type="submit"
                            text="Submit" />
                        <Button
                            text="Reset"
                            color="default"
                            onClick={resetForm} />
                </Box>
            </Box>
        </Form>
    )
}