import React from 'react'

const Single = () => {
  return (
    <div>Single</div>
  )
}

export default Single