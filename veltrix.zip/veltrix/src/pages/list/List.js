import React from 'react'

const list = () => {
  return (
    <div>list</div>
  )
}

export default list