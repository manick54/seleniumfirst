import { Box, Button, IconButton, Typography } from "@mui/material";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import Widget from "../../components/widget/Widget";
import Chart from "../../components/chart/Chart";
import Featured from "../../components/featured/Featured";
import ProgressBar from '../../components/progressbar/ProgressBar';
import BasicTimeline from '../../components/timeline/Timeline';
import Orders from '../../components/orders/Orders';
import Product from '../../components/product/Product';
import Table from "../../components/table/Table";







const Home = () => {


    return (
        <Box m="20px">
            {/* HEADER */}
            <Box display="flex" justifyContent="space-between" alignItems="center">

                <Box>

                </Box>
            </Box>

            {/* GRID & CHARTS */}
            <Box
                display="grid"
                gridTemplateColumns="repeat(12, 1fr)"
                gridAutoRows="140px"
                gap="20px"
            >
                {/* ROW 1 */}
                <Box
                    gridColumn="span 3"
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                >
                    {<Widget
                        title="12,361"
                        subtitle="Emails Sent"
                        progress="0.75"
                        increase="+14%"
                        type="user"

                    />}
                </Box>
                <Box
                    gridColumn="span 3"

                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                >
                    {<Widget
                        title="12,361"
                        subtitle="Emails Sent"
                        progress="0.75"
                        increase="+14%"
                        type="order"

                    />}
                </Box>
                <Box
                    gridColumn="span 3"
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                >
                    {<Widget
                        title="12,361"
                        subtitle="Emails Sent"
                        progress="0.75"
                        increase="+14%"
                        type="earning"

                    />}
                </Box>
                <Box
                    gridColumn="span 3"
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                >
                    {<Widget
                        title="12,361"
                        subtitle="Emails Sent"
                        progress="0.75"
                        increase="+14%"
                        type="balance"

                    />}
                </Box>

                {/* ROW 2 */}
                <Box
                    gridColumn="span 8"
                    gridRow="span 3"
                //backgroundColor="blue"
                >

                    <Box height="100%" m="20px 0 0 0">
                        <Chart title="Last 6 Months (Revenue)" aspect={2 / 1} />
                    </Box>
                </Box>
                <Box
                    gridColumn="span 4"
                    gridRow="span 2"
                    //backgroundColor="blue"
                    overflow="auto"
                >
                    <Box
                        display="flex"
                        justifyContent="space-between"
                        alignItems="center"
                        //borderBottom="4px solid green"
                        colors="grey"
                    //p="15px"
                    >

                    </Box>

                    <Box
                        // key={`${transaction.txId}-${i}`}
                        display="flex"
                        justifyContent="space-between"
                        alignItems="center"
                        borderBottom="4px solid grey"
                        p="15px"
                    >

                        <Featured />
                    </Box>

                </Box>

                {/* ROW 3 */}
                <Box
                    gridColumn="span 4"
                    gridRow="span 3"
                //backgroundColor="blue"
                // p="30px"
                >

                    <Box
                        display="flex"
                        flexDirection="column"
                        alignItems="center"
                        mt="25px"
                    >

                        <Orders />
                    </Box>
                    <Box
                        display="flex"
                        flexDirection="column"
                        alignItems="center"
                        mt="25px"
                    >

                        <Product />




                    </Box>
                </Box>
                <Box
                    gridColumn="span 4"
                    gridRow="span 3"
                //backgroundColor="blue"
                >

                    <Box height="100%" >
                        <ProgressBar />

                    </Box>

                </Box>
                <Box
                    gridColumn="span 4"
                    gridRow="span 2"
                // backgroundColor="blue"
                //padding="30px"
                >


                    <BasicTimeline />


                </Box>

            </Box>
            <Box
                    gridColumn="span 8"
                    gridRow="span 6"
                    mt="25px"
                //backgroundColor="blue"
                >
                    
              <Table />
                </Box>
        </Box>
    );
};

export default Home;
