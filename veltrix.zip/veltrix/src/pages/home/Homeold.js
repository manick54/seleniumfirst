import React from 'react'
import "./home.scss";
import Navbar from "../../components/navbar/Navbar";
import Widget from "../../components/widget/Widget";
import Chart from "../../components/chart/Chart";
import Featured from '../../components/featured/Featured';
import ProgressBar from '../../components/progressbar/ProgressBar';
import Table from "../../components/table/Table";
import Chat from '../../components/chat/Chat';
import Orders from '../../components/orders/Orders';
import Product from '../../components/product/Product';
import ClientReview from '../../components/clientreview/ClientReview';
import BasicTimeline from '../../components/timeline/Timeline';
import Sidebar from '../../components/sidebar/Sidebar';
import Box from '@mui/material/Box';

const Home = () => {
  return (

      <div className='home'>
            <div className="widgets">
              <Widget type="user" />
              <Widget type="order" />
              <Widget type="earning" />
              <Widget type="balance" />
            </div>
            <div className="charts">

              <Chart title="Last 6 Months (Revenue)" aspect={2 / 1} />
              <Featured />
            </div>
            <div className='progressBlock'>
              <div>
                <ProgressBar />
              </div>

              <div className='sideContainer'>
                <div className='sideBlock'>
                  <BasicTimeline />
                  <Orders />
                  <Product />
                </div>

                <div className='clienBlock'>
                  <ClientReview />
                </div>
              </div>

            </div>
            <div className="listContainer">
              <div className="listTitle">Latest Transactions</div>
              <Table />
            </div>


          
         

      </div>
    
    
  )
}

export default Home