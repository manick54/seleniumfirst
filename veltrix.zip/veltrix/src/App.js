import {
  BrowserRouter,Router,
  Routes,
  Route,
} from "react-router-dom";
import Home from "./pages/home/Home";
import List from "./pages/list/List";
import New from "./pages/new/New";
import Single from "./pages/single/Single"
import ProfileForm from "./pages/profileform/ProfileForm"
import React from 'react'
import Navbar from "./components/navbar/Navbar";
import Sidebar from "./components/sidebar/Sidebar";
import {useState} from "react";


function App() {
  const [isSidebar, setIsSidebar] = useState(true);
  return (
    <div className="app">
      <BrowserRouter>
      <Sidebar isSidebar={isSidebar} />
          <main className="content">
          <Navbar setIsSidebar={setIsSidebar} />

     
    <Routes>
      
      <Route path="/" element={<Home />} />
              <Route path="/list" element={<List />} />
              <Route path="/profileform" element={<ProfileForm />} />
              <Route path="/new" element={<New />} />
              <Route path="/single" element={<Single />} />
      
    </Routes>
  
  </main>
  </BrowserRouter>
  </div>
  );
}

export default App;
