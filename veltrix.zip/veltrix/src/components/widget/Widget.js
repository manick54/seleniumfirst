import React from 'react'
import "./widget.scss";
import AccountBalanceWalletOutlinedIcon from "@mui/icons-material/AccountBalanceWalletOutlined";
import AddIcon from '@mui/icons-material/Add';
import NorthIcon from '@mui/icons-material/North';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import EventRepeatIcon from '@mui/icons-material/EventRepeat';
import NoteIcon from '@mui/icons-material/Note';
import DriveFileRenameOutlineIcon from '@mui/icons-material/DriveFileRenameOutline';
import BusinessCenterIcon from '@mui/icons-material/BusinessCenter';
import SouthIcon from '@mui/icons-material/South';

const Widget = ({ type }) => {
  let data;

  //temporary
  const amount = 100;
  const diff = 20;

  switch (type) {
    case "user":
      data = {
        title: "USERS",
        isMoney: false,
        link: "Since last month",
        icon: (
          <EventRepeatIcon
            className="icon"
            style={{
                backgroundColor: "rgba(255,255,255,.15)",
                color: "#fff",
                fontSize:'35px',
                padding:'15px',
            }}
          />
        ),
          icon1:(
            <NorthIcon
            className="icon"
            style={{
                color: "green",
                 }}
          />

          ),
        
      };
      break;
    case "order":
      data = {
        title: "ORDERS",
        isMoney: false,
        link: "Since last month",
                icon: (
          <AccountBalanceWalletOutlinedIcon
            className="icon"
            style={{
                backgroundColor: "rgba(255,255,255,.15)",
                color: "#fff",
                fontSize:'35px',
                padding:'15px',
            }}
          />
        ),
        icon1:(
            <NorthIcon
            className="icon"
            style={{
                color: "green",
            }}
          />

          ),
      };
      break;
    case "earning":
      data = {
        title: "EARNINGS",
        isMoney: true,
        link: "Since last month",
        icon: (
          <DriveFileRenameOutlineIcon
            className="icon"
            style={{ backgroundColor: "rgba(255,255,255,.15)",
            color: "#fff",
            fontSize:'35px',
            padding:'15px',}}
          />
        ),
        icon1:(
            <SouthIcon
            className="icon"
            style={{
                color: "red",
            }}
          />

          ),
      };
      break;
    case "balance":
      data = {
        title: "BALANCE",
        isMoney: true,
        link: "Since last month",
        icon: (
          <BusinessCenterIcon
            className="icon"
            style={{
              backgroundColor: "rgba(255,255,255,.15)",
              color: "#fff",
              fontSize:'35px',
              padding:'15px',
            }}
          />
        ),
        icon1:(
            <NorthIcon
            className="icon"
            style={{
                color: "green",
                 }}
          />

          ),
      };
      break;
    default:
      break;
  }

  return (
    <div className="widget">
      <div className="left">
      {data.icon}
      </div>

      <div className="right">

        <span className="title">{data.title}</span>
        <div class="money">
        <span className="counter">
          {data.isMoney && "$"} {amount} </span>

          <span className="iconstyle">
          {data.icon1}
          </span>
          </div>

        <div>
        <span className="link">{data.link}</span>
</div>
      </div>
        <div className="percentage positive">
          <div className='mini-stat-label bg-success'>
          +{diff} %
          </div>
          <ArrowForwardIcon />

          </div>

        

    </div>
  );
};

export default Widget;