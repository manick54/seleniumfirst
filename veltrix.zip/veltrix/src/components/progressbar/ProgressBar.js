import React, { useCallback, useState } from "react";
import { PieChart, Pie, Sector, Tooltip } from "recharts";
import "./progressbar.scss";
import EventOutlinedIcon from '@mui/icons-material/EventOutlined';
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";


const rows = [
  {
    
    amount: '54.5%',
    method: "Desktop",
    status: "Desk",
  },
  {
    amount: '28.8%',
    method: "Mobile",
    status: "Mob",
  },
  {
    amount: '17.5%',
    method: "Tablets",
    status: "tab",
  },
];
const data = [
  { name: "Group A", value: 400 , fill: '#f8b425'},
  { name: "Group B", value: 300, fill: "#02a499" },
  { name: "Group C", value: 300, fill: "#626ed4" }
];


const renderActiveShape = (props) => {
  const RADIAN = Math.PI / 180;
  const {
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    startAngle,
    endAngle,
    fill,
    payload,
    percent,
    value
  } = props;
  const sin = Math.sin(-RADIAN * midAngle);
  const cos = Math.cos(-RADIAN * midAngle);
  const sx = cx + (outerRadius + 10) * cos;
  const sy = cy + (outerRadius + 10) * sin;
  const mx = cx + (outerRadius + 30) * cos;
  const my = cy + (outerRadius + 30) * sin;
  const ex = mx + (cos >= 0 ? 1 : -1) * 22;
  const ey = my;
  const textAnchor = cos >= 0 ? "start" : "end";

  return (
    <g>
      <text x={cx} y={cy} dy={8} textAnchor="middle" fill={fill}>
        {payload.name}
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
      <Sector
        cx={cx}
        cy={cy}
        startAngle={startAngle}
        endAngle={endAngle}
        innerRadius={outerRadius + 6}
        outerRadius={outerRadius + 10}
        fill={fill}
      />
      <path
        d={`M${sx},${sy}L${mx},${my}L${ex},${ey}`}
        stroke={fill}
        fill="none"
      />
      <circle cx={ex} cy={ey} r={2} fill={fill} stroke="none" />
      <text
        x={ex + (cos >= 0 ? 1 : -1) * 12}
        y={ey}
        textAnchor={textAnchor}
        fill="#333"
      >{`PV ${value}`}</text>
      <text
        x={ex + (cos >= 0 ? 1 : -1) * 12}
        y={ey}
        dy={18}
        textAnchor={textAnchor}
        fill="#999"
      >
        {`(Rate ${(percent * 100).toFixed(2)}%)`}
      </text>
    </g>
  );
};

export default function ProgressBar() {
  const [activeIndex, setActiveIndex] = useState(0);
  const onPieEnter = useCallback(
    (_, index) => {
      setActiveIndex(index);
    },
    [setActiveIndex]
  );

  return (
    <div className="progressContainer">
      <h5>Sales Report</h5>
      <div className="title">
        <div className="sidedev">
        <span><EventOutlinedIcon/></span>
        <span > Jan 01 - Jan 04</span>
        </div>
        <div>
        <span className="boldClass">$4,230</span>
        </div>
      </div>
    <PieChart width={250} height={200}>
      <Pie
        activeIndex={activeIndex}
        activeShape={renderActiveShape}
        data={data}
        cx={150}
        cy={100}
        innerRadius={60}
        outerRadius={80}
        fill="#8884d8"
        dataKey="value"
        onMouseEnter={onPieEnter}
      />
            

    </PieChart>

    <div className="tableblock">
    <TableContainer component={Paper} className="table">
      <Table sx={{ minWidth: 300 }} aria-label="simple table">
      <TableBody>
          {rows.map((row) => (
            <TableRow key={row.id}>
              <TableCell className="tableCell">
                <span className={`status ${row.status}`}>{row.status}</span>
              </TableCell>
             
              <TableCell className="tableCell">{row.method}</TableCell>
              <TableCell className="tableCell">{row.amount}</TableCell>
              
            </TableRow>
          ))}
        </TableBody>
        </Table>
        </TableContainer>
    </div>
    </div>
  );
}
