import React from 'react'
import './product.scss'
import Typography from '@mui/material/Typography';
import Link from '@mui/material/Link';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';



const Product = () => {
  return (
    <div className='productBlock'>
      <Card sx={{ minWidth: 275 }} className='cardBg'>
      <CardContent>

      <Typography variant="h3" gutterBottom>
      top product sale
      </Typography>
      <Typography variant="h2" gutterBottom>
        1452
      </Typography>
      <Typography variant="h4" gutterBottom>
        computer
      </Typography>
      <Typography variant="body1" gutterBottom>
      At solmen va esser necessi far uniform myth....
      <Link href="#">View more</Link>

      </Typography>
      </ CardContent>

      </Card>
      </div>
  )
}

export default Product