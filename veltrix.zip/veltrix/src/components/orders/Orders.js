import React from 'react'
import "./orders.scss"
import TaskAltOutlinedIcon from '@mui/icons-material/TaskAltOutlined';

import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

const Orders = () => {
  return (
    <div className='order'>


      
        <Card sx={{ maxWidth: 345 }}>
        <div className="cardBody">
          <TaskAltOutlinedIcon className='tickIcon'/>
          
          <CardContent>
            <Typography className='textSuccess' variant="h5" component="div">
              Order Successful
            </Typography>
            <Typography variant="body2" className='textNormal'>
              Thanks you so much for your order.
            </Typography>
          </CardContent>
          </div>
          <CardActions className='cardButton'>
            <Button variant="contained" size="small">Check Status</Button>
          </CardActions>
          
        </Card>

      </div>
    



  )
}

export default Orders