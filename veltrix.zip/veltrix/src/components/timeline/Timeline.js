import React from 'react'
import Timeline from '@mui/lab/Timeline';
import TimelineItem from '@mui/lab/TimelineItem';
import TimelineSeparator from '@mui/lab/TimelineSeparator';
import TimelineConnector from '@mui/lab/TimelineConnector';
import TimelineContent from '@mui/lab/TimelineContent';
import TimelineDot from '@mui/lab/TimelineDot';
import Button from '@mui/material/Button';
import './timeline.scss'
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';



export default function BasicTimeline() {
  return (
    <div className='timelineBlock'>
     <Card>
    <Timeline>.
      <TimelineItem>
        <TimelineSeparator>
          <TimelineDot className='dotBg'/>
          <TimelineConnector />
        </TimelineSeparator>
        <div className='timelineContent'>
        <TimelineContent className='contentStyle'>JAN 22</TimelineContent>
        <TimelineContent className='contentStyle'>Responded to need “Volunteer Activities”</TimelineContent>
        </div>
        </TimelineItem>
      <TimelineItem>
        <TimelineSeparator>
          <TimelineDot className='dotBg'/>
          <TimelineConnector />
        </TimelineSeparator>
        <div className='timelineContent'>
        <TimelineContent className='contentStyle'>JAN 22</TimelineContent>
        <TimelineContent className='contentStyle'>Responded to need “Volunteer Activities”</TimelineContent>
        </div>
      </TimelineItem>
      
      <TimelineItem>
        <TimelineSeparator>
          <TimelineDot className='dotBg'/>
          <TimelineConnector />
        </TimelineSeparator>
        <div className='timelineContent'>
        <TimelineContent className='contentStyle'>JAN 22</TimelineContent>
        <TimelineContent className='contentStyle'>Responded to need “Volunteer Activities”</TimelineContent>
        </div>
      </TimelineItem>
      <TimelineItem>
        <TimelineSeparator>
          <TimelineDot className='dotBg' />
        </TimelineSeparator>
        <div className='timelineContent'>
        <TimelineContent className='contentStyle'>JAN 22</TimelineContent>
        <TimelineContent className='contentStyle'>Responded to need “Volunteer Activities”</TimelineContent>
        </div>
      </TimelineItem>
      

    </Timeline>
    <CardActions className='cardButton'>
            <Button variant="contained" size="small">LOAD MORE</Button>
          </CardActions>
    
    </Card>
    </div>
    
  );
}
