import React from 'react'
import { useState } from 'react';
import "./navbar.scss";
import SearchOutlinedIcon from "@mui/icons-material/SearchOutlined";
import LanguageOutlinedIcon from "@mui/icons-material/LanguageOutlined";
import FullscreenIcon from '@mui/icons-material/Fullscreen';
import FullscreenExitOutlinedIcon from "@mui/icons-material/FullscreenExitOutlined";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import ChatBubbleOutlineOutlinedIcon from "@mui/icons-material/ChatBubbleOutlineOutlined";
import SettingsOutlinedIcon from '@mui/icons-material/SettingsOutlined';
import ListOutlinedIcon from "@mui/icons-material/ListOutlined";
import LaunchRoundedIcon from '@mui/icons-material/LaunchRounded';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';

import ListItemIcon from '@mui/material/ListItemIcon';
import IconButton from '@mui/material/IconButton';
import Tooltip from '@mui/material/Tooltip';
import Avatar from '@mui/material/Avatar';
import Link from '@mui/material/Link';
import ArrowCircleRightIcon from '@mui/icons-material/ArrowCircleRight';

import ShoppingCartOutlinedIcon from '@mui/icons-material/ShoppingCartOutlined';
import MessageOutlinedIcon from '@mui/icons-material/MessageOutlined';
import Divider from '@mui/material/Divider';
import LocalBarIcon from '@mui/icons-material/LocalBar';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import Fade from '@mui/material/Fade';
import Button from '@mui/material/Button';
import SelectUnstyled, {
  SelectUnstyledProps,
  selectUnstyledClasses,
} from '@mui/base/SelectUnstyled';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { Typography } from '@mui/material';

//import { DarkModeContext } from "../../context/darkModeContext";
//import { useContext } from "react";
const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};

const Navbar = () => {
  // const { dispatch } = useContext(DarkModeContext);
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const [openModal, setOpenModal] = React.useState(false);
  const handleOpenModal = () => setOpenModal(true);
  const handleCloseModal = () => setOpenModal(false);
  
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div className="navbar">
      <div className="wrapper">
        
      


        <div className="items">
          <div className="search item">
            <input type="text" placeholder="Search..." />
            <SearchOutlinedIcon />
          </div>
          
          <div className='item'>
          <Tooltip title="Account settings">
          <IconButton
            onClick={handleClick}
            size="small"
            sx={{ ml: 2 }}
            aria-controls={open ? 'account-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={open ? 'true' : undefined}
          >
            <NotificationsNoneOutlinedIcon sx={{ width: 32, height: 32 }}/>
          </IconButton>
        </Tooltip>
        <div className="counter">1</div>

          <Menu
          className='menuContent'
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: 'visible',
            filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
            mt: 1.5,
            '& .MuiAvatar-root': {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            '&:before': {
              content: '""',
              display: 'block',
              position: 'absolute',
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: 'background.paper',
              transform: 'translateY(-50%) rotate(45deg)',
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
       
       
        <MenuItem className='d-flex'>
          <ListItemIcon className='cartBg iconBg'>
            <ShoppingCartOutlinedIcon fontSize="small" fill="#fff"/>
          </ListItemIcon>
          <div className='notifiContent'>
          <h6>Your order is placed</h6>
           <p>Dummy text of the printing and typesetting industry.</p>
           </div>
        </MenuItem>
        <MenuItem className='d-flex'>
          <ListItemIcon className='msgBg iconBg'>
            <MessageOutlinedIcon fontSize="small" />
          </ListItemIcon>
          <div className='notifiContent'>
          <h6>New Mesaage Received</h6>
           <p>You have 87 Unread Messages.</p>
           </div>
        </MenuItem>
        <MenuItem className='d-flex'>
          <ListItemIcon className='wineBg iconBg'>
            <LocalBarIcon fontSize="small" />
          </ListItemIcon>
          <div className='notifiContent'>
          <h6>Your item is Shipped</h6>
           <p>It is a long established fact that a reader will</p>
           </div>
        </MenuItem>
        <Divider />
        <div className='item'>
        <Link href="#" className="btnLink" underline="hover"><ArrowCircleRightIcon fontSize='small'/>View All</Link>
        </div>
      </Menu>
          </div>
        
          <div className="item">
            <img
              src="https://images.pexels.com/photos/941693/pexels-photo-941693.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500"
              alt=""
              className="avatar"
            />
          </div>
          <div className='item'>
      <Button className="iconColor" onClick={handleOpenModal} ><LaunchRoundedIcon sx={{ width: 32, height: 32 }}/></Button>
      <Modal
        open={openModal}
        onClose={handleCloseModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Text in a modal
          </Typography>
          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            Duis mollis, est non commodo luctus, nisi erat porttitor ligula.
          </Typography>
        </Box>
      </Modal>
    </div>
          
        </div>
      </div>
    </div>
  );
};

export default Navbar;